KRISSIA PORTFOLIO - how to edit

Files
  index.html   page structure and text
  style.css    design, colors (light/dark variables at the top), animations
  script.js    behavior. TRAITS and PROJECTS lists are at the very top
  assets/      all images cut from your Figma export

Add a trait:    script.js -> TRAITS -> add { name: "...", desc: "..." }
Edit a project: script.js -> PROJECTS -> change desc, link, button text, tags
Add a project:  copy one project block, add the image to assets/
Resume:         put resume.pdf next to index.html
Facebook link:  index.html -> search for "Replace the # below"
Colors:         style.css -> :root (light) and [data-theme="dark"] (dark)
